# วิธีการ run Pacman

1. download files ทั้งหมด
2.  unzip file ที่ download มา
3. เปิด folder ที่ download มา และทำการเปิด open folder ใน VS code
4.  download Python interpreter และ Python extension สำหรับ VS code
5.  ทำการ run python ที่ pacman.py file
